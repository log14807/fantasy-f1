// ============================================================
// FANTASY F1 LEAGUE — RESULTS DATA FILE
// ============================================================
// HOW TO UPDATE EACH RACE WEEKEND:
// 1. Add the new round to the ROUNDS array below
// 2. Fill in qualifying, sprint (if applicable), and race results
// 3. Use 99 for DNF/DNS/no time set
// 4. Save the file — standings update automatically
// ============================================================

const LEAGUE_CONFIG = {
  name: "Fantasy F1 League",
  season: 2026,
  // Top 3 constructors for Best of the Rest (update if standings change)
  topConstructors: ["Mercedes", "Ferrari", "McLaren"]
};

// ============================================================
// TEAMS & ROSTERS
// ============================================================
const TEAMS = [
  {
    id: "t1",
    name: "Curious George Russell",
    owner: "Team 1",
    color: "#3399ff",
    drivers: ["Russell", "Lindblad", "Ocon", "Bortoleto"]
  },
  {
    id: "t2",
    name: "Hadjar Heard of This",
    owner: "Team 2",
    color: "#ff4444",
    drivers: ["Hamilton", "Hadjar", "Hulkenberg", "Lawson"]
  },
  {
    id: "t3",
    name: "Colapinto's Franks & Beans",
    owner: "Team 3",
    color: "#ff8800",
    drivers: ["Leclerc", "Piastri", "Albon", "Colapinto"]
  },
  {
    id: "t4",
    name: "Team 4",
    owner: "Team 4",
    color: "#e8ff00",
    drivers: ["Norris", "Antonelli", "Sainz", "Perez"]
  },
  {
    id: "t5",
    name: "FleetWood Max and the Boys",
    owner: "Team 5",
    color: "#00ff88",
    drivers: ["Verstappen", "Bearman", "Gasly", "Alonso"]
  }
];

// ============================================================
// DRIVER → CONSTRUCTOR MAP (update if drivers change teams)
// ============================================================
const DRIVER_CONSTRUCTOR = {
  Russell: "Mercedes",    Antonelli: "Mercedes",
  Hamilton: "Ferrari",    Leclerc: "Ferrari",
  Norris: "McLaren",      Piastri: "McLaren",
  Verstappen: "Red Bull", Hadjar: "Red Bull", Lawson: "Racing Bulls",  Lindblad: "Racing Bulls",
  Bearman: "Haas",        Ocon: "Haas",
  Gasly: "Alpine",        Colapinto: "Alpine",
  Hulkenberg: "Audi",     Bortoleto: "Audi",
  Albon: "Williams",      Sainz: "Williams",
  Alonso: "Aston Martin", Stroll: "Aston Martin",
  Perez: "Cadillac",      Bottas: "Cadillac"
};

// ============================================================
// ROUNDS
// ============================================================
// FORMAT FOR EACH ROUND:
// {
//   id: "r1",
//   name: "Australian Grand Prix",
//   circuit: "Albert Park",
//   flag: "🇦🇺",
//   date: "8 Mar 2026",
//   sprint: false,          // true if sprint weekend
//   lineups: {
//     t1: ["Driver1", "Driver2", "Driver3"],  // 3 starters (bench driver excluded)
//     ...
//   },
//   qualifying: { Driver: position, ... },   // use 99 for no time
//   sprint: { Driver: position, ... },        // only if sprint weekend
//   race: { Driver: position, ... }           // use 99 for DNF/DNS
// }

const ROUNDS = [

  // ─────────────────────────────────────────
  // ROUND 1 — AUSTRALIA
  // ─────────────────────────────────────────
  {
    id: "r1",
    name: "Australian Grand Prix",
    circuit: "Albert Park, Melbourne",
    flag: "🇦🇺",
    date: "8 Mar 2026",
    isSprint: false,
    lineups: {
      t1: ["Russell", "Lindblad", "Ocon"],
      t2: ["Hamilton", "Hadjar", "Lawson"],
      t3: ["Leclerc", "Piastri", "Albon"],
      t4: ["Norris", "Antonelli", "Sainz"],
      t5: ["Verstappen", "Gasly", "Bearman"]
    },
    qualifying: {
      Russell: 1, Antonelli: 2, Hadjar: 3, Leclerc: 4, Piastri: 5,
      Norris: 6, Hamilton: 7, Lawson: 8, Lindblad: 9, Bortoleto: 10,
      Hulkenberg: 11, Bearman: 12, Ocon: 13, Gasly: 14, Albon: 15,
      Colapinto: 16, Alonso: 17, Perez: 18, Bottas: 19,
      Verstappen: 99, Sainz: 99, Stroll: 99
    },
    race: {
      Russell: 1, Antonelli: 2, Leclerc: 3, Hamilton: 4, Norris: 5,
      Verstappen: 6, Bearman: 7, Lindblad: 8, Bortoleto: 9, Gasly: 10,
      Ocon: 11, Sainz: 12, Stroll: 13, Lawson: 14,
      Albon: 99, Hadjar: 99, Piastri: 99, Hulkenberg: 99, Alonso: 99
    }
  },

  // ─────────────────────────────────────────
  // ROUND 2 — CHINA (SPRINT WEEKEND)
  // ─────────────────────────────────────────
  {
    id: "r2",
    name: "Chinese Grand Prix",
    circuit: "Shanghai International Circuit",
    flag: "🇨🇳",
    date: "15 Mar 2026",
    isSprint: true,
    lineups: {
      t1: ["Russell", "Lindblad", "Bortoleto"],
      t2: ["Hamilton", "Hadjar", "Lawson"],
      t3: ["Leclerc", "Piastri", "Albon"],
      t4: ["Norris", "Antonelli", "Sainz"],
      t5: ["Verstappen", "Gasly", "Bearman"]
    },
    qualifying: {
      Antonelli: 1, Russell: 2, Hamilton: 3, Leclerc: 4, Norris: 5,
      Piastri: 6, Verstappen: 7, Gasly: 8, Bearman: 9, Hadjar: 10,
      Sainz: 11, Alonso: 12, Ocon: 13, Colapinto: 14, Stroll: 15,
      Bortoleto: 16, Hulkenberg: 17, Albon: 18, Lindblad: 19, Lawson: 20,
      Bottas: 99, Perez: 99
    },
    sprintRace: {
      Russell: 1, Leclerc: 2, Hamilton: 3, Norris: 4, Antonelli: 5,
      Piastri: 6, Lawson: 7, Bearman: 8, Verstappen: 9, Ocon: 10,
      Gasly: 11, Sainz: 12, Bortoleto: 13, Colapinto: 14, Hadjar: 15,
      Albon: 16, Alonso: 17, Stroll: 18, Lindblad: 99, Bottas: 99, Hulkenberg: 99
    },
    race: {
      Antonelli: 1, Russell: 2, Hamilton: 3, Leclerc: 4, Bearman: 5,
      Gasly: 6, Lawson: 7, Hadjar: 8, Sainz: 9, Colapinto: 10,
      Hulkenberg: 11, Lindblad: 12, Bottas: 13, Ocon: 14, Perez: 15,
      Verstappen: 99, Alonso: 99, Stroll: 99,
      Norris: 99, Piastri: 99, Bortoleto: 99, Albon: 99
    }
  }

  // ─────────────────────────────────────────
  // ROUND 3 — JAPAN (add after race weekend)
  // ─────────────────────────────────────────
  // COPY THIS TEMPLATE AND FILL IN:
  // {
  //   id: "r3",
  //   name: "Japanese Grand Prix",
  //   circuit: "Suzuka",
  //   flag: "🇯🇵",
  //   date: "29 Mar 2026",
  //   isSprint: false,
  //   lineups: {
  //     t1: ["Driver", "Driver", "Driver"],
  //     t2: ["Driver", "Driver", "Driver"],
  //     t3: ["Driver", "Driver", "Driver"],
  //     t4: ["Driver", "Driver", "Driver"],
  //     t5: ["Driver", "Driver", "Driver"]
  //   },
  //   qualifying: { Driver: pos, Driver: pos, ... },
  //   race: { Driver: pos, Driver: pos, ... }
  // },

];
