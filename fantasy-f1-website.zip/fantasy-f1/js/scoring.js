// ============================================================
// SCORING ENGINE
// ============================================================

const SCORING = {
  race: (pos) => {
    if (pos === 1) return 50;
    if (pos === 2) return 40;
    if (pos === 3) return 35;
    if (pos === 4) return 30;
    if (pos === 5) return 25;
    if (pos === 6) return 20;
    if (pos <= 9) return 15;
    if (pos <= 12) return 10;
    if (pos <= 15) return 5;
    return 0;
  },
  qualifying: (pos) => {
    if (pos === 1) return 25;
    if (pos <= 3) return 15;
    if (pos <= 6) return 10;
    if (pos <= 10) return 5;
    return 0;
  },
  sprint: (pos) => {
    if (pos === 1) return 25;
    if (pos === 2) return 20;
    if (pos === 3) return 15;
    if (pos <= 6) return 10;
    if (pos <= 10) return 5;
    return 0;
  }
};

function getDriverStatus(pos, driver, round, session) {
  if (pos === 99) {
    const dnsList = session === 'race'
      ? (round.id === 'r2' ? ['Norris','Piastri','Bortoleto','Albon'] : ['Piastri','Hulkenberg'])
      : [];
    return dnsList.includes(driver) ? 'DNS' : 'DNF';
  }
  return null;
}

function calcDriverRoundScore(driver, round) {
  const result = {
    qualiPts: 0,
    sprintPts: 0,
    racePts: 0,
    total: 0,
    qualiPos: round.qualifying?.[driver] || 99,
    sprintPos: round.sprintRace?.[driver] || 99,
    racePos: round.race?.[driver] || 99,
    raceStatus: null,
    sprintStatus: null
  };

  result.qualiPts = SCORING.qualifying(result.qualiPos);

  if (round.isSprint && round.sprintRace) {
    if (result.sprintPos === 99) result.sprintStatus = 'DNF';
    else result.sprintPts = SCORING.sprint(result.sprintPos);
  }

  if (result.racePos === 99) {
    result.raceStatus = 'DNF';
  } else {
    result.racePts = SCORING.race(result.racePos);
  }

  result.total = result.qualiPts + result.sprintPts + result.racePts;
  return result;
}

function calcTeamRoundScore(teamId, round) {
  const team = TEAMS.find(t => t.id === teamId);
  const lineup = round.lineups[teamId];
  if (!lineup) return { total: 0, drivers: {} };

  let total = 0;
  const drivers = {};

  for (const driver of lineup) {
    const score = calcDriverRoundScore(driver, round);
    drivers[driver] = score;
    total += score.total;
  }

  return { total, drivers };
}

function calcAllStandings() {
  const standings = TEAMS.map(team => {
    let grandTotal = 0;
    const rounds = [];

    for (const round of ROUNDS) {
      const roundScore = calcTeamRoundScore(team.id, round);
      grandTotal += roundScore.total;
      rounds.push({
        roundId: round.id,
        roundName: round.name,
        flag: round.flag,
        total: roundScore.total,
        drivers: roundScore.drivers
      });
    }

    return {
      ...team,
      grandTotal,
      rounds
    };
  });

  return standings.sort((a, b) => b.grandTotal - a.grandTotal);
}

function getLastRound() {
  return ROUNDS[ROUNDS.length - 1] || null;
}
