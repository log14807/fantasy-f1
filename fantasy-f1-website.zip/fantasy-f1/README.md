# Fantasy F1 2026 — League Website

## 🚀 One-Time Setup (GitHub Pages — Free)

### Step 1 — Create a GitHub account
1. Go to **github.com**
2. Click **Sign up** and create a free account

### Step 2 — Create a new repository
1. Once logged in, click the **+** button (top right) → **New repository**
2. Name it: `fantasy-f1` (or whatever you want)
3. Make sure it is set to **Public**
4. Click **Create repository**

### Step 3 — Upload the files
1. On your new repository page, click **uploading an existing file**
2. Drag and drop ALL of these files/folders:
   - `index.html`
   - `breakdown.html`
   - `scoring.html`
   - `css/` folder (with `style.css` inside)
   - `js/` folder (with `scoring.js` inside)
   - `data/` folder (with `results.js` inside)
3. Scroll down, click **Commit changes**

### Step 4 — Turn on GitHub Pages
1. Click **Settings** (tab at the top of your repo)
2. Click **Pages** (left sidebar)
3. Under "Branch", select **main** and click **Save**
4. Wait ~60 seconds, refresh the page
5. You'll see: **"Your site is live at https://YOURNAME.github.io/fantasy-f1"**

That's it! Share that link with your league.

---

## 📅 Updating After Each Race Weekend

The **only file you ever need to edit** is: `data/results.js`

### How to edit it on GitHub:
1. Go to your repository on github.com
2. Click on the `data` folder → click `results.js`
3. Click the **pencil icon** (Edit this file) top right
4. Scroll to the bottom of the `ROUNDS` array
5. Copy the template comment at the bottom and fill in:
   - Round name, circuit, flag, date
   - `isSprint: true` or `false`
   - **Lineups** — which 3 drivers each team is starting
   - **Qualifying** positions (use `99` for no time set)
   - **sprintRace** positions (only if sprint weekend)
   - **Race** positions (use `99` for DNF or DNS)
6. Click **Commit changes** at the bottom
7. Wait ~30 seconds — the website updates automatically!

### Example — adding a new round:
```js
{
  id: "r3",
  name: "Japanese Grand Prix",
  circuit: "Suzuka",
  flag: "🇯🇵",
  date: "29 Mar 2026",
  isSprint: false,
  lineups: {
    t1: ["Russell", "Lindblad", "Ocon"],
    t2: ["Hamilton", "Hadjar", "Lawson"],
    t3: ["Leclerc", "Piastri", "Albon"],
    t4: ["Norris", "Antonelli", "Sainz"],
    t5: ["Verstappen", "Gasly", "Bearman"]
  },
  qualifying: {
    Russell: 1, Hamilton: 2, Norris: 3, ...
  },
  race: {
    Norris: 1, Russell: 2, Hamilton: 3, ...
  }
},
```

### Position shortcuts:
- `99` = DNF, DNS, or no time set
- Always use the exact driver name spelling from the existing data

---

## 📱 What the site includes

| Page | URL | What it shows |
|------|-----|---------------|
| Standings | `/index.html` | Full league table + podium + latest round |
| Breakdown | `/breakdown.html` | Per-driver scores for each round |
| Scoring | `/scoring.html` | Official scoring rules |

---

## 🏎️ Scoring Rules (built into the site)

**Race (P1–P15):** 50 / 40 / 35 / 30 / 25 / 20 / 15 / 15 / 15 / 10 / 10 / 10 / 5 / 5 / 5

**Qualifying (P1–P10):** 25 / 15 / 15 / 10 / 10 / 10 / 5 / 5 / 5 / 5

**Sprint Race (P1–P10):** 25 / 20 / 15 / 10 / 10 / 10 / 5 / 5 / 5 / 5

**Sprint Qualifying:** Not scored
